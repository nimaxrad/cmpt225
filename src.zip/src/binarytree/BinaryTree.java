package binarytree;

import java.lang.reflect.Array;
import java.util.*;
import java.util.function.Function;

public class BinaryTree<T> {

    private BTNode<T> root;

    public BinaryTree(BTNode<T> root) {
        this.root = root;
    }

    public BTNode<T> getRoot() {
        return root;
    }

    public int size() {
        return root.size();
    }

    public int height() {
        return root.height();
    }

    public void printInOrder() {
        root.printInOrder();
    }

    public void printPreOrder() {
        root.printPreOrder();
    }

    public void printPostOrder() {
        root.printPostOrder();
    }

    /**************** Assignment 3 *************************/


    /**
     * returns the number of leaves in the tree
     */
    public int numberOfLeaves() {
        int total=0;
        BinaryTree<T> subtree = new BinaryTree<T>(root);
        if(subtree.getRoot().getLeftChild()==null && subtree.getRoot().getRightChild()==null){
            return 1;
        }
        if(subtree.getRoot().getLeftChild()!=null){
            BinaryTree<T> leftTree = new BinaryTree<>(subtree.getRoot().getLeftChild());
            total+=leftTree.numberOfLeaves();
        }
        if(subtree.getRoot().getRightChild()!=null){
            BinaryTree<T> rightTree = new BinaryTree<>(subtree.getRoot().getRightChild());
            total+=rightTree.numberOfLeaves();
        }
        //System.out.println("hellssso23323424\n");
        //System.out.println(total);
        // TODO implement me
        return total;
    }


    @Override
    public boolean equals(Object other) {
        boolean isEqual=true;
        BinaryTree<T> subtree = new BinaryTree<T>(root);
        BinaryTree<T> otherTree=(BinaryTree<T>) other;
        BinaryTree<T> othersubtree = new BinaryTree<T>(otherTree.getRoot());

        if(subtree.getRoot().getData()!=othersubtree.getRoot().getData()){
            return false;
        }

        if(subtree.getRoot().getLeftChild()==null && subtree.getRoot().getRightChild()==null){
            if(subtree.getRoot().getData()!=othersubtree.getRoot().getData())
                return false;
        }

        if(subtree.getRoot().getLeftChild()!=null){
            if(othersubtree.getRoot().getLeftChild()==null){
                return false;
            }
            BinaryTree<T> leftTree = new BinaryTree<>(subtree.getRoot().getLeftChild());
            BinaryTree<T> otherlefttree = new BinaryTree<>(othersubtree.getRoot().getLeftChild());
            return leftTree.equals(otherlefttree);
        }

        if(subtree.getRoot().getRightChild()!=null){
            if(othersubtree.getRoot().getRightChild()==null){
                return false;
            }
            BinaryTree<T> rightTree = new BinaryTree<>(subtree.getRoot().getRightChild());
            BinaryTree<T> otherrighttree = new BinaryTree<>(othersubtree.getRoot().getRightChild());
            return rightTree.equals(otherrighttree);
        }
        String a = "hello";
        // System.out.println(subtree.getRoot().getData().hashCode());
        // System.out.println(othersubtree.getRoot().getData().hashCode());
        // System.out.println(subtree.getRoot().getLeftChild().getData().hashCode());
        // System.out.println(othersubtree.getRoot().getLeftChild().getData().hashCode());

        //String b =

        return isEqual;
        // TODO implement me
    }

//
    /**
     * returns the number of vertices at depth k if k<0 throws
     * IllegalArgumentException
     */
    public int countDepthK(int k) {
        int currentdepth=0;
        ArrayList<Integer> list = new ArrayList<>();
        list = depthList(root,currentdepth,list);
        int count=0;
        //System.out.println(depthList(root,currentdepth,list));
        for (Integer integer : list) {
            if (k == integer)
                count++;
        }
//        //number of nodes at depth k
//        if(k==0) return 1;
//
//        // TODO implement me
        return count;
    }
    //start with root,0,emptylist
    public ArrayList<Integer> depthList(BTNode<T> nroot, int currentdepth, ArrayList<Integer> current){
        //if(currentdepth==5) System.out.println(nroot.getData());
        ArrayList<Integer> listOfDepths = new ArrayList<>();
        //listOfDepths.addAll(current);
        listOfDepths.add(currentdepth);
        //System.out.println(listOfDepths);
        if(nroot.getLeftChild()!=null){
            currentdepth+=1;
            listOfDepths.addAll(depthList(nroot.getLeftChild(),currentdepth,listOfDepths));
        }
        if(nroot.getRightChild()!=null){
            if(nroot.getLeftChild()==null){
                currentdepth+=1;
            }
            listOfDepths.addAll(depthList(nroot.getRightChild(),currentdepth,listOfDepths));
        }

        return listOfDepths;
    }

    /**
     * returns a preOrder iterator for the tree
     */
    public Iterator<T> preOrderIterator() {
        return new PreOrderIterator<>(root);
        // TODO implement me

    }

}
