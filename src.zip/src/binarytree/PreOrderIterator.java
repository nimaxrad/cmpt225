package binarytree;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

/**
 * Preorder iterator (root, left, right) using java.util.Stack.
 *
 * This version is "dynamic" — it reads children at visit-time.
 * So, if the tree changes in the parts not yet visited, the iterator
 * will see those changes when it gets there.
 */
public class PreOrderIterator<T> implements Iterator<T> {

    private Stack<BTNode<T>> stack = new Stack<>();

    public PreOrderIterator(BTNode<T> root) {
        if (root != null) {
            stack.push(root);
        }
    }

    @Override
    public boolean hasNext() {
        return !stack.isEmpty();
    }

    @Override
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }

        BTNode<T> node = stack.pop();

        // Read children NOW (dynamic behavior)
        if (node.getRightChild() != null) {
            stack.push(node.getRightChild());
        }
        if (node.getLeftChild() != null) {
            stack.push(node.getLeftChild());
        }

        return node.getData();
    }
}
