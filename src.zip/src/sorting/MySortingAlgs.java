package sorting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;
import java.util.Comparator;

public class MySortingAlgs {

    public static void sortStrings(String[] a) {
        //System.out.println(Arrays.asList(a));
        int index=0, change=0;
        for(String outerLoop: a){
            change=0;
            for(String innerloop: a){
                if(outerLoop.length()>innerloop.length() && index<change){
                    String tmp = a[change];
                    a[change] = a[index];
                    a[index] = tmp;
                }

                change++;
            }
            index++;
        }
        index=0;
        change=0;
        for(String outer: a){
            change=0;
            for(String inner: a){
                if(inner.length()==outer.length() && !(outer.compareTo(inner)<0) && index<change){
                    String tmp = a[index];
                    a[index] = a[change];
                    a[change] = tmp;
                }
                change++;
            }
            index++;
        }


        //System.out.println(Arrays.asList(a));
        // TODO implement me
    }


	/**
	 * Assumption arr[start...mid-1] is sorted and arr[mid...end] is sorted.
     * The function merges the two parts into a sorted subarray arr[start...end]
     * All elements outside arr[start...end] remain unchanged
	 */
	public static <T extends Comparable<T>> void merge(T[] arr, int start, int mid, int end) {
        int index=0;
        //System.out.print(Arrays.asList(arr));
        for(T outerLoop: arr){
            if(index>end) break;
            if(index<start) {index++;continue;}
            //System.out.println(index);
            int change=0;
            for(T innerloop: arr){
                if(change>end) break;
                if(change<start){change++; continue;}
                if((outerLoop.compareTo(innerloop)<0)){
                    T tmp = arr[change];
                    arr[change] = arr[index];
                    arr[index] = tmp;
                }
                change++;
            }
            index++;
        }
        //System.out.print(Arrays.asList(arr));
        // TODO implement me
	}


	/**
	 * sorts the subarray arr[start...end] using the Merge Sort algorithm
	 */
    public static <T extends Comparable<T>> void mergeSort(T[] arr, int start, int end) {
        if (start == end)
            return;

        int mid = (start + end) / 2;
        mergeSort(arr, start, mid-1);
        mergeSort(arr, mid, end);
        merge(arr, start, mid, end);
    }

    /**
     * sorts the subarray arr using the Merge Sort algorithm
     */
    public static <T extends Comparable<T>> void mergeSort(T[] arr) {
        mergeSort(arr,0,arr.length-1);
    }

}
