package assignment2;
import java.util.ArrayList;
import basicdatastructures.stack.*;
import java.util.NoSuchElementException;
import javax.lang.model.type.NullType;
import java.io.*;
public class MyStackOperations {
	/**
	 * Returns the number of elements in s.
	 */
	public static <T> int size(Stack<T> s) {
        Stack<T> backup=new StackLinkedListBased<>();

        ArrayList<T> elements = new ArrayList<>();
//        System.out.println(backup);

        int count = 0;
        T tmp;
        while(!s.isEmpty()){
            count++;
            tmp = s.pop();
            elements.add(tmp);
            //System.out.println("--> " + tmp);
        }
        //System.out.println("end");
        int fill = count;
        while(fill>0){
            s.push(elements.get(fill-1));
            fill--;
        }

        //System.out.println("end");
		return count;
	}

	/**
	 * Removes the bottom element from the stack, and returns it.
     * The remaining elements are kept in the same order.
     * If s is empty, the method throws NoSuchElementException.
	 */
    public static <T> T removeBottom(Stack<T> s) {
        if(s.isEmpty()) throw new NoSuchElementException();
        Stack<T> backup =new StackLinkedListBased<>();
        ArrayList<T> elements = new ArrayList<>();


        int count = 0;
        T tmp = null;
        while(!s.isEmpty()){
            count++;
            tmp = s.pop();
            elements.add(tmp);
            //System.out.println("****> " + tmp);
        }

        //if(s.isEmpty()) System.out.println("s empty");
        int fill = count;
        fill--;
        int index = 0;
        while(fill>0){
            //System.out.println("fill: " + (fill-1) + elements.get(fill-1));
            s.push(elements.get(fill-1));
            fill--;
        }
//        }
//		// TODO implement me
        //System.out.println("tmp: " + tmp);

		return tmp;
	}

	/**
	 * Reverses the order of the elements in s.
	 */
	public static <T> void reverse(Stack<T> s) {
        if(s.isEmpty()) throw new NoSuchElementException();
        Stack<T> backup =new StackLinkedListBased<>();
        ArrayList<T> elements = new ArrayList<>();


        int count = 0;
        T tmp = null;
        while(!s.isEmpty()){
            count++;
            tmp = s.pop();
            elements.add(tmp);

        }
        int index=0;
        while(index<count){
            s.push(elements.get(index));
            index++;
        }

		// TODO implement me
	}

	/**
	 * Checks if the two stacks have the same items in the same order. The items in
	 * the queues are compared using == operator.
	 */
	public static <T> boolean areEqual(Stack<T> s1, Stack<T> s2) {
        Boolean flag=true;
        Stack<T> backup1 =new StackLinkedListBased<>();
        ArrayList<T> elements1 = new ArrayList<>();
        ArrayList<T> elements2 = new ArrayList<>();

        if(s1.isEmpty() &&  s2.isEmpty()) return true;
        if(size(s1) != size(s2)) return false;
        T tmp;
        int count=0;
        while(!s1.isEmpty()){

            elements1.add(s1.pop());
            elements2.add(s2.pop());
            if(elements1.get(count)!=elements2.get(count)) return false;
            count++;
        }
        while(count>0){
            s1.push(elements1.get(count-1));
            s2.push(elements2.get(count-1));
            count--;
        }

		// TODO implement me
		return true;
	}
}
