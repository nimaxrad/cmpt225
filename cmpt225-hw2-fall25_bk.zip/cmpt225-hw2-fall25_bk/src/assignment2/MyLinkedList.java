package assignment2;
import java.util.NoSuchElementException;
import java.util.ArrayList;
/**
 *
 * This is a generic class representing a list of objects.
 * The operations on the list are as follows:
 * - adding and removing elements from the left and from the right.
 * - reversing the list
 * - getting the size of the list
 * 
 * **All operations must run in O(1) time.**
 */

public class MyLinkedList<T> { // T use a type parameter so we can have deifferent linkedlists
    private static class Node<E> { //using static to create a class inside linkedlist
        E val;
        Node<E> prev;
        Node <E> next;
        public Node(E v)
        {
            this.val = v;
        }
    }


    private Node<T> head;
    private Node<T> tail;
    private int size;
    private boolean reversed;

    /**
	 * The constructor creates an empty list
	 */
	public MyLinkedList() {
        head = null;
        tail = null;
        size = 0;
        reversed = false;
	}

	/**
	 * Adds the new item to the left of the list. 
	 */
	public void addLeft(T item) {
        if (!reversed) {
            addHead(item);
        }
        else{
            addTail(item);
        }

	}

	/**
	 * Adds the new item to the right of the list. 
	 */
	public void addRight(T item) {
        if (!reversed) {
            addTail(item);
        }
        else{
            addHead(item);
        }
	}

	/**
	 * Removes the leftmost item from the list and returns it.
	 * If the list is empty, throws NoSuchElementException.
	 */
	public T removeLeft() {
        if (isEmpty()) throw new NoSuchElementException();
        if(!reversed){
            return removeHead();
        }else{
            return removeTail();
        }
	}

	/**
	 * Removes the rightmost item from the list and returns it.
	 * If the list is empty, throws NoSuchElementException.
	 */
	public T removeRight() {
        if (isEmpty()) throw new NoSuchElementException();
        if(!reversed){
            return removeTail();
        }else{
            return removeHead();
        }
	}
    private void addHead(T item) {
        Node<T>n = new Node<>(item);
        n.next = head;
        if (head!= null) head.prev = n;
        head =n;
        if(tail== null) tail = n;
        size++;
    }

    private void addTail(T item) {
        Node<T>n = new Node<>(item);
        n.prev =tail;
        if (tail!= null) tail.next = n;
        tail =n;
        if (head== null) head = n;
        size++;
    }

    private T removeHead() {
        T v = head.val;
        head = head.next;
        if (head !=null) head.prev = null;
        else tail =null;
        size--;
        return v;
    }

    private T removeTail() {
        T v = tail.val;
        tail = tail.prev;
        if (tail !=null) tail.next = null;
        else head= null;
        size--;
        return v;
    }

	/**
	 * Reverses the list
	 */
	public void reverse() {
        reversed = !reversed;
    }

	/**
	 * Returns the size of the list.
	 */
	public int size() {
        return size;
	}

	/**
	 * Returns true if list is empty, and returns false otherwise.
	 */
	public boolean isEmpty() {
		return size==0;
	}

}
